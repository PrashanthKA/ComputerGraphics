# Kolandaiswami Arjunan, Prashanth
# 1001-110-082
# 2016-05-02
# Assignment_05

import sys
import OpenGL
from math import *
from OpenGL.GL import *     
from OpenGL.GLU import *    
from OpenGL.GLUT import *
from random import randint

yAngle = 0
xFactor=0
numOfLists=0;
xAngle = 0
scaling_fact = 1
zAngle = 0


verticesdictionary=[]
filename = "pyramid_05.txt"
cameras_count = 0
facelist=[]
projection_flag = 0
projection = "parallel"
faces_count = 0
vertices_count = 0
cameralist = [ ]
class camera:
        vup=[]
        t = "parallel"
        e=[]
        l=[]
        s = [0.1, 0.1, 0.9, 0.9]
        distance = 0
        vpn = [0,0,0]
        i = ""
        v =[0,0,0]
        u =[0,0,0]
        
        d1=[0,0,0]
        tag =""
        d2=[0,0,0]
        zmin = 0.0
        d3=[0,0,0]
        window = [-1 , 1, -1, 1, -1, 1]
        distance1 =[0,0,0]
        sx=0.0
        distance3 =[0,0,0]
        sy=0.0
        distance2 =[0,0,0]
        
        def __init__(self):
           pass

def readobjectfile ():
    global xAngle
    
    global yAngle 
    global zAngle
    xAngle = yAngle =zAngle = 0

    global scaling_fact
    scaling_fact = 1
    
    global filename
    file = open(filename,'r')
    global verticesdictionary
    global facelist
    verticesdictionary=[]
    facelist=[]
    for c in cameralist:
        c.distance1=[0,0,0]
        c.distance2=[0,0,0]
        c.distance3=[0,0,0]
        
    for line in file:
            #print(line)
            if line [0] =='v':
                tempLine = line[2:-1]
                splitStr = tempLine.split()
                tempLine.rstrip()                
                verticesdictionary.append(splitStr)
            elif line[0]=='f':
                tempLine = line[2:-1]
                splitStr = tempLine.split()
                tempLine.rstrip() 
                facelist.append(splitStr)       
    
            
def create_object():
        
        NewVertices = []
        global numOfLists
        global x
        for V in verticesdictionary:
            
            temp = [V[0],V[1],V[2]]
            
            NewVertices.append(temp)
        numOfLists=1
        xFactor=1
        for face in facelist:
          glNewList(numOfLists,GL_COMPILE)
          glBegin(GL_POLYGON)
          if(xFactor==1):
            glColor3f(0,0,1)
          elif(xFactor==2):
            glColor3f(0,1,0)
          elif(xFactor==3):
            glColor3f(0,1,1)
          elif(xFactor==4):
            glColor3f(1,0,0)
          elif(xFactor==5):
            glColor3f(1,0,1)
          elif(xFactor==6):
            glColor3f(1,1,0)
          elif(xFactor==7):
            glColor3f(1,1,1)
          elif(xFactor==8):
            glColor3f(0,0,0)
          
          for f in face:            
            glVertex3f(float(NewVertices[int(f)-1][0]),float(NewVertices[int(f)-1][1]),float(NewVertices[int(f)-1][2]))
          glEnd()
          glEndList()
          numOfLists = numOfLists+1
          xFactor = xFactor+1
          if(xFactor==9):
            xFactor=1;

def readCameraFile():
#        glClear(GL_COLOR_BUFFER_BIT)        
        global cameras_count
        file_camera = open("cameras_05.txt",'r')
        
        first = 0
        tempobject = camera()
        for eachline in file_camera:
                if eachline[0] == 'c':
                    #its new camera object
                    cameras_count += 1
                    if(first==1):
                        
                        cameralist.append(tempobject)
                    else:
                        first = 1
                    tempobject = camera()
                elif eachline[0] == 'i':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.i = splitStr[0]
                elif eachline[0] == 't':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.t = splitStr[0]
                elif eachline[0] == 'e':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.e = splitStr
                elif eachline[0] == 'l':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.l = splitStr
                elif eachline[0] == 'u':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.vup = splitStr
                elif eachline[0] == 'w':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.window = splitStr
                elif eachline[0] == 's':
                    tempLine = eachline[2:-1]
                    splitStr = tempLine.rsplit()
                    tempobject.s = splitStr
                

        cameralist.append(tempobject)
        readobjectfile ()

def display():
        
      global cameras_count
      global vertices_count
      global faces_count
      global type_of_proj
      global cameralist
      w=glutGet(GLUT_WINDOW_WIDTH)
      h=glutGet(GLUT_WINDOW_HEIGHT)
     
      for c in cameralist:
          
              viewport = c.s
#              print("Viewport",viewport)
#              print("W",w)
#              print("H",h)
              x = float(viewport[0])*float(w)
              
#              print("X: ",x)
              y = float(viewport[1])*float(h)
             
#              print ("Y : ",y)
              z = float(viewport[2])*float(w)
              
#              print ("Z : ",z)
              a = float(viewport[3])*float(h)
             
#              print("A :", a)
#              print("Viewports:")
#              print(viewport[0],viewport[1],viewport[2],viewport[3])
#              glEnable(GL_DEPTH_TEST)
              glEnable(GL_SCISSOR_TEST)
              glScissor(int(x),int(h-a),int(z-x),int(a-y))
#              glScissor(int(x1),int(y1),int(z1),int(a1))
              glClearColor(0.4+(x/1000),0.4+(y/1000),0.6+(z/1000),0)
              glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
              glMatrixMode(GL_PROJECTION)
              glLoadIdentity()
              
              if(c.t == "perspective" and projection_flag == 0):
                 
                  glFrustum(float(c.window[0]),float(c.window[1]),float(c.window[2]),float(c.window[3]),float(c.window[4]),float(c.window[5]))
              elif(c.t == "parallel" and projection_flag == 0):
                  glOrtho(float(c.window[0]),float(c.window[1]),float(c.window[2]),float(c.window[3]),float(c.window[4]),float(c.window[5]))
              elif(c.t == "parallel" and projection_flag == 1):
                 
                  glFrustum(float(c.window[0]),float(c.window[1]),float(c.window[2]),float(c.window[3]),float(c.window[4]),float(c.window[5]))
              elif(c.t == "perspective" and projection_flag == 1):
                  glOrtho(float(c.window[0]),float(c.window[1]),float(c.window[2]),float(c.window[3]),float(c.window[4]),float(c.window[5]))
              
              gluLookAt(float(c.e[0])+float(c.distance1[0])+float(c.distance2[0])+float(c.distance3[0]),float(c.e[1])+float(c.distance1[1])+float(c.distance2[1])+float(c.distance3[1]),float(c.e[2])+float(c.distance1[2])+float(c.distance2[2])+float(c.distance3[2]),float(c.l[0]),float(c.l[1]),float(c.l[2]),float(c.vup[0]),float(c.vup[1]),float(c.vup[2]))
              glMatrixMode(GL_MODELVIEW)    
              glViewport(int(x),int(h-a),int(z-x),int(a-y))
              glScalef(scaling_fact,scaling_fact,scaling_fact)
              glRotated(xAngle,1,0,0)
              glRotated(yAngle,0,1,0)
              glRotated(zAngle,0,0,1)
              for x in range(numOfLists):
                glCallList(x+1) 
              
              glFlush()
              glLoadIdentity()    
      glutSwapBuffers()                             
def Special_Keys(Key,x,y):
            
            if Key == GLUT_KEY_LEFT:
                    for c in cameralist:
                        c.distance2 = [float(c.distance2[0])+(float(c.d2[0])*0.05),float(c.distance2[1])+(float(c.d2[1])*0.05),float(c.distance2[2])+(float(c.d2[2])*0.05)]
                        
            elif Key == GLUT_KEY_RIGHT:
                    for c in cameralist:
                        c.distance2 = [float(c.distance2[0])-(float(c.d2[0])*0.05),float(c.distance2[1])-(float(c.d2[1])*0.05),float(c.distance2[2])-(float(c.d2[2])*0.05)]

            elif Key == GLUT_KEY_UP:
                    for c in cameralist:
                        c.distance3 = [float(c.distance3[0])+(float(c.d3[0])*0.05),float(c.distance3[1])+(float(c.d3[1])*0.05),float(c.distance3[2])+(float(c.d3[2])*0.05)]

                
            elif Key == GLUT_KEY_DOWN:
                    for c in cameralist:
                        c.distance3 = [float(c.distance3[0])-(float(c.d3[0])*0.05),float(c.distance3[1])-(float(c.d3[1])*0.05),float(c.distance3[2])-(float(c.d3[2])*0.05)]

                              
            else:
                    print ("No Arrow key")
                    
#            readCameraFile()
def keyHandler(Key, MouseX, MouseY):
      global Incr
      global xAngle
      global yAngle
      global zAngle
      global scaling_fact
      
      global type_of_proj
      global filename
      global projection_flag
      global verticesdictionary
      global facelist
      if Key == b'p' :
            if(projection_flag == 0):
                  projection_flag = 1
            elif(projection_flag == 1):
                  projection_flag = 0
            
#     rotation      
      elif Key == b'z':
            zAngle += 5
            
      elif Key == b'Z':
            zAngle -= 5
            
      elif Key == b'x':
            xAngle += 5
                             
      elif Key == b'X':
                  xAngle -= 5 
                  
      elif Key == b'y':
                  yAngle += 5 
                  
      elif Key == b'Y':
                  yAngle -= 5
                  
#     scaling
      elif Key == b's':
                  scaling_fact *= 1.05 
                  
      elif Key == b'S':
                  scaling_fact *= (20/21)  
                  
      elif Key == b'n':
            
             filename = input("Enter file name : ")
             
      elif Key == b'd':
           readobjectfile ()
           print("Display")
           create_object()
           
      elif Key == b'f':
          for c in cameralist:
              c.distance1 = [float(c.distance1[0])+(float(c.d1[0])*0.05),float(c.distance1[1])+(float(c.d1[1])*0.05),float(c.distance1[2])+(float(c.d1[2])*0.05)]
                        
                  
      elif Key == b'b':
          for c in cameralist:
              c.distance1 = [float(c.distance1[0])-(float(c.d1[0])*0.05),float(c.distance1[1])-(float(c.d1[1])*0.05),float(c.distance1[2])-(float(c.d1[2])*0.05)]
 
      elif Key == b'q' or Key == b'Q':
            print ("Bye")
            sys.exit()
      else:
            print ("Invalid Key ",Key)
      display()
def timer(dummy):
      display()
      glutTimerFunc(30,timer,0)
def reshape(w, h):
      print ("Width=",w,"Height=",h)
          
glutInit(sys.argv)
glutInitDisplayMode(GLUT_DOUBLE|GLUT_RGB|GLUT_DEPTH)
glutInitWindowSize(1000, 500)
glutInitWindowPosition(100, 100)
glutCreateWindow(b"PyOpenGL Demo_abc")
glClearColor(0,0,0,0)
glPolygonMode(GL_FRONT_AND_BACK,GL_FILL)
glEnable(GL_DEPTH_TEST)
glDepthFunc(GL_LESS)
glClear(GL_COLOR_BUFFER_BIT)
readCameraFile()
glutDisplayFunc(display)
glutKeyboardFunc(keyHandler)
glutSpecialFunc(Special_Keys)
glutTimerFunc(300,timer,0)
glutReshapeFunc(reshape)
create_object()
glutMainLoop()

